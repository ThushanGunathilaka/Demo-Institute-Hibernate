/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.console;

import com.demoinstitute.entity.Address;
import com.demoinstitute.entity.Course;
import com.demoinstitute.entity.Lecturer;
import com.demoinstitute.entity.Student;
import com.demoinstitute.services.CourseService;
import com.demoinstitute.services.LecturerService;
import com.demoinstitute.services.StudentService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Research
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StudentService studentService = new StudentService();
        CourseService courseService = new CourseService();
        LecturerService lecturerService = new LecturerService();
        Logger log = Logger.getLogger(Main.class.getName());
        
        //R.09 - Create Students
        Address student1Address = new Address();
        student1Address.setHouseNo("65/33");
        student1Address.setRoadName("Kandy Road");
        student1Address.setCity("Malabe");
        student1Address.setCountry("Sri Lanka");
        
        Student student1 = new Student();
        student1.setNicNo("927656351V");
        student1.setRegistrationId("DIT-13-M1-0056");
        student1.setFirstName("Jackie");
        student1.setLastName("Chan");
        student1.setDateOfBirth("05/27/1992");
        student1.setAddress(student1Address);

        boolean status = studentService.createStudent(student1);
        if (status) {
            log.log(Level.INFO, "Student 1 Inserted");
            log.log(Level.INFO, student1.toString());
        } else {
            log.log(Level.SEVERE, "Student 1 Not Inserted");
        }

        Address student2Address = new Address();
        student2Address.setHouseNo("21/5");
        student2Address.setRoadName("Galle Road");
        student2Address.setCity("Mount Lavania");
        student2Address.setCountry("Sri Lanka");
        
        Student student2 = new Student();
        student2.setNicNo("936724590V");
        student2.setRegistrationId("DIT-14-M1-0023");
        student2.setFirstName("Jet");
        student2.setLastName("Li");
        student2.setDateOfBirth("03/12/1993");
        student2.setAddress(student2Address);

        status = studentService.createStudent(student2);
        if (status) {
            log.log(Level.INFO, "Student 2 Inserted");
            log.log(Level.INFO, student2.toString());
        } else {
            log.log(Level.SEVERE, "Student 2 Not Inserted");
        }

        Address student3Address = new Address();
        student3Address.setHouseNo("29/35");
        student3Address.setRoadName("Kandy Road");
        student3Address.setCity("Peradeniya");
        student3Address.setCountry("Sri Lanka");
        
        Student student3 = new Student();
        student3.setNicNo("854524340V");
        student3.setRegistrationId("DIT-06-M1-0010");
        student3.setFirstName("Adrian");
        student3.setLastName("Monk");
        student3.setDateOfBirth("10/10/1985");
        student3.setAddress(student3Address);

        status = studentService.createStudent(student3);
        if (status) {
            log.log(Level.INFO, "Student 3 Inserted");
            log.log(Level.INFO, student3.toString());
        } else {
            log.log(Level.SEVERE, "Student 3 Not Inserted");
        }

        Address student4Address = new Address();
        student4Address.setHouseNo("11/32");
        student4Address.setRoadName("Galle Road");
        student4Address.setCity("Panadura");
        student4Address.setCountry("Sri Lanka");
        
        Student student4 = new Student();
        student4.setNicNo("903476126V");
        student4.setRegistrationId("DIT-11-M1-0009");
        student4.setFirstName("Patrick");
        student4.setLastName("Jane");
        student4.setDateOfBirth("09/09/1990");
        student4.setAddress(student4Address);

        status = studentService.createStudent(student4);
        if (status) {
            log.log(Level.INFO, "Student 4 Inserted");
            log.log(Level.INFO, student4.toString());
        } else {
            log.log(Level.SEVERE, "Student 4 Not Inserted");
        }

        //R.10 - Create Lecturers
        Address lecturer1Address = new Address();
        lecturer1Address.setHouseNo("99/99");
        lecturer1Address.setRoadName("Chinatown");
        lecturer1Address.setCity("San Fransisco");
        lecturer1Address.setCountry("USA");
       
        Lecturer lecturer1 = new Lecturer();
        lecturer1.setNicNo("401782987V");
        lecturer1.setSpecialities("Martial Arts");
        lecturer1.setFirstName("Bruce");
        lecturer1.setLastName("Lee");
        lecturer1.setDateOfBirth("11/27/1940");
        lecturer1.setAddress(lecturer1Address);

        status = lecturerService.createLecturer(lecturer1);
        if (status) {
            log.log(Level.INFO, "Lecturer 1 Inserted");
            log.log(Level.INFO, lecturer1.toString());
        } else {
            log.log(Level.SEVERE, "Lecturer 1 Not Inserted");
        }

        Address lecturer2Address = new Address();
        lecturer2Address.setHouseNo("221/B");
        lecturer2Address.setRoadName("Baker Street");
        lecturer2Address.setCity("London");
        lecturer2Address.setCountry("UK");
        
        Lecturer lecturer2 = new Lecturer();
        lecturer2.setNicNo("541084368V");
        lecturer2.setSpecialities("Homicide Detective");
        lecturer2.setFirstName("Sherlok");
        lecturer2.setLastName("Holms");
        lecturer2.setDateOfBirth("2/22/1950");
        lecturer2.setAddress(lecturer2Address);

        status = lecturerService.createLecturer(lecturer2);
        if (status) {
            log.log(Level.INFO, "Lecturer 2 Inserted");
            log.log(Level.INFO, lecturer2.toString());
        } else {
            log.log(Level.SEVERE, "Lecturer 2 Not Inserted");
        }

        //R.11 - Create Courses
        Course course1 = new Course();
        course1.setCourseId("MA-SHKU");
        course1.setCourseName("Shaolin Kung Fu");
        course1.setCourseDuration(100);

        status = courseService.createCourse(course1);
        if (status) {
            log.log(Level.INFO, "Course MA-SHKU Inserted");
            log.log(Level.INFO, course1.toString());
        } else {
            log.log(Level.SEVERE, "Course MA-SHKU Not Inserted");
        }

        Course course2 = new Course();
        course2.setCourseId("MA-WUSH");
        course2.setCourseName("Wushu");
        course2.setCourseDuration(80);

        status = courseService.createCourse(course2);
        if (status) {
            log.log(Level.INFO, "Course MA-WUSH Inserted");
            log.log(Level.INFO, course2.toString());
        } else {
            log.log(Level.SEVERE, "Course MA-WUSH Not Inserted");
        }

        Course course3 = new Course();
        course3.setCourseId("HO-INVE");
        course3.setCourseName("Homocide Inestigation");
        course3.setCourseDuration(60);

        status = courseService.createCourse(course3);
        if (status) {
            log.log(Level.INFO, "Course HO-INVE Inserted");
            log.log(Level.INFO, course3.toString());
        } else { 
            log.log(Level.SEVERE, "Course HO-INVE Not Inserted");
        }
        
        //R.12 - Assign Lectuers for Courses
        course1.setConductedLecturer(lecturer1);
        if(courseService.updateCourse(course1)) {
            log.log(Level.INFO, "Lecturer 1 Assigned to Course MA-SHKU (1)");
            log.log(Level.INFO, course1.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Assign Lecturer 1 to Course MA-SHKU (1)");
        }
        
        course2.setConductedLecturer(lecturer1);
        if (courseService.updateCourse(course2)) {
            log.log(Level.INFO, "Lecturer 1 Assigned to Course MA-WUSH (2)");
            log.log(Level.INFO, course2.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Assign Lecturer 1 to Course MA-WUSH (2)");
        }
        
        course3.setConductedLecturer(lecturer2);
        if (courseService.updateCourse(course3)) {
            log.log(Level.INFO, "Lecturer 2 Assigned to Course HO-INVE (3)");
            log.log(Level.INFO, course3.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Assign Lecturer 2 to Course HO-INVE (3)");
        }
        
        //R.13 - Enroll Students
        Collection<Course> courseList;

        courseList = student1.getListOfCourses();
        if (courseList == null) {
            courseList = new ArrayList<>();
        } 
        courseList.add(course1);
        student1.setListOfCourses(courseList);
        if (studentService.updateStudent(student1)) {
            log.log(Level.INFO, "Student 1 Enrolled to Course MA-SHKU (1)");
            log.log(Level.INFO, student1.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Enroll Student 1 to Course MA-SHKU (1)");
        }
        
        courseList = student2.getListOfCourses();
        if (courseList == null) {
            courseList = new ArrayList<>();
        }
        courseList.add(course1);
        student2.setListOfCourses(courseList);
        if (studentService.updateStudent(student2)) {
            log.log(Level.INFO, "Student 2 Enrolled to Course MA-SHKU (1)");
            log.log(Level.INFO, student2.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Enroll Student 2 to Course MA-SHKU (1)");
        }
        
        courseList = student2.getListOfCourses();
        if (courseList == null) {
            courseList = new ArrayList<>();
        }
        courseList.add(course2);
        student2.setListOfCourses(courseList);
        if (studentService.updateStudent(student2)) {
            log.log(Level.INFO, "Student 2 Enrolled to Course MA-WUSH (2)");
            log.log(Level.INFO, student2.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Enroll Student 2 to Course MA-WUSH (2)");
        }
        
        courseList = student3.getListOfCourses();
        if (courseList == null) {
            courseList = new ArrayList<>();
        }
        courseList.add(course3);
        student3.setListOfCourses(courseList);
        if (studentService.updateStudent(student3)) {
            log.log(Level.INFO, "Student 3 Enrolled to Course HO-INVE (3)");
            log.log(Level.INFO, student3.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Enroll Student 3 to Course HO-INVE (3)");
        }
        
        courseList = student4.getListOfCourses();
        if (courseList == null) {
            courseList = new ArrayList<>();
        }
        courseList.add(course3);
        student4.setListOfCourses(courseList);
        if (studentService.updateStudent(student4)) {
            log.log(Level.INFO, "Student 4 Enrolled to Course HO-INVE (3)");
            log.log(Level.INFO, student4.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Enroll Student 4 to Course HO-INVE (3)");
        }
        
        courseList = student4.getListOfCourses();
        if (courseList == null) {
            courseList = new ArrayList<>();
        }
        courseList.add(course1);
        student4.setListOfCourses(courseList);
        if (studentService.updateStudent(student4)) {
            log.log(Level.INFO, "Student 4 Enrolled to Course MA-SHKU (1)");
            log.log(Level.INFO, student4.toString());
        } else { 
            log.log(Level.SEVERE, "Failed to Enroll Student 4 to Course MA-SHKU (1)");
        }

        //Q.14
        String courseId = "MA-SHKU";
        Collection<Student> students;
        students = studentService.listStudentsFollowingCourse(courseId);
        System.out.println("\n***Students who are following course " +
                courseId +
                "***\n***Start***");
        for (Student item : students) {
            System.out.println("NIC No = " +
                    item.getNicNo() +
                    " | Registration No = " +
                    item.getRegistrationId() +
                    " | Full Name = " +
                    item.getFirstName() +
                    " " + item.getLastName());
        }
        System.out.println("***End***");
    }
}
