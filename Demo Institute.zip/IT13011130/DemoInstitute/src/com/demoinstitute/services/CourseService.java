/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.services;

import com.demoinstitute.entity.Course;
import com.demoinstitute.util.SessionFactoryUtil;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.derby.impl.tools.sysinfo.Main;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Research
 */
public class CourseService {
    private static Logger logger;

    public CourseService() {
        logger = Logger.getLogger(Main.class.getName());
    }
 
    public boolean createCourse(Course course) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.save(course);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Create Course transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public boolean updateCourse(Course course) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.update(course);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Update Course transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public boolean deleteCourse(Course course) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.delete(course);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Delete Course transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public Course getCourse(String courseID) {
        Course course = new Course();
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            course = (Course) session.get(Course.class, courseID);
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Course Selection transaction");
                }
                throw ex;
            }
        }
        return course;
    }
}
