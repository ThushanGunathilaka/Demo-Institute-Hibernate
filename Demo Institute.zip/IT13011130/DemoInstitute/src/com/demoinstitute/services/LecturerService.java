/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.services;

import com.demoinstitute.entity.Lecturer;
import com.demoinstitute.util.SessionFactoryUtil;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.derby.impl.tools.sysinfo.Main;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Research
 */
public class LecturerService {
    private static Logger logger = null;

    public LecturerService() {
        logger = Logger.getLogger(Main.class.getName());
    }
 
    public boolean createLecturer(Lecturer lecturer) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.save(lecturer);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Create Lecturer transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public boolean updateLecturer(Lecturer lecturer) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.update(lecturer);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Update Lecturer transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public boolean deleteLecturer(Lecturer lecturer) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.delete(lecturer);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Delete Lecturer transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public Lecturer getLecturer(String nic) {
        Lecturer lecturer = new Lecturer();
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            lecturer = (Lecturer) session.get(Lecturer.class, nic);
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Leturer Selection transaction");
                }
                throw ex;
            }
        }
        return lecturer;
    }
}
