/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.services;

import com.demoinstitute.entity.Student;
import com.demoinstitute.util.SessionFactoryUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.derby.impl.tools.sysinfo.Main;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Research
 */
public class StudentService {
    private static Logger logger = null;

    public StudentService() {
        logger = Logger.getLogger(Main.class.getName());
    }
 
    public boolean createStudent(Student student) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.save(student);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Create Student transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public boolean deleteStudent(Student student) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.delete(student);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Delete Student transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public boolean updateStudent(Student student) {
        boolean status = false;
        Transaction tx = null;
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            tx = session.beginTransaction();
            session.update(student);
            tx.commit();
            status = true;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Update Student transaction");
                }
                throw ex;
            }
        }
        return status;
    }

    public Student selectStudent(String nic) {
        Transaction tx = null;
        Student student = new Student();
        Session session = SessionFactoryUtil.getCurrentSession();
        try {
            student = (Student) session.get(Student.class, nic);
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Student Selection transaction");
                }
                throw ex;
            }
        }
        return student;
    }

    public Collection<Student> listStudentsFollowingCourse(String courseID) {
        Transaction tx =null;
        Collection<Student> students = new ArrayList<>();
        String hql = "SELECT s.enrolledStudents FROM COURSE_TAB s WHERE  s.courseId = :course_Id";  
        try{
            Session session = SessionFactoryUtil.getCurrentSession();
            tx = session.beginTransaction();
            Query query = session.createQuery(hql);
            query.setString("course_Id", courseID);    
            students = query.list();
            tx.commit();
        }
        catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (HibernateException e1) {
                    logger.log(Level.SEVERE, "Error while rolling back Course List Selection transaction");
                }
                throw ex;
            }
        }
        return students;
    }
}
