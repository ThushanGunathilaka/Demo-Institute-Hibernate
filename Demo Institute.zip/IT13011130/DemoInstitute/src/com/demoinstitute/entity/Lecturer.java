/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

/**
 *
 * @author Research
 */
@Entity(name="LECTURER_TAB")
public class Lecturer extends Person implements Serializable {
    @Column(name = "SPECIALITIES")
    private String specialities;
    
    @OneToMany(cascade = CascadeType.ALL,mappedBy="courseId")
    private Collection<Course> listOfCourses;

    public String getSpecialities() {
        return specialities;
    }

    public void setSpecialities(String specialities) {
        this.specialities = specialities;
    }

    public Collection<Course> getListOfCourses() {
        return listOfCourses;
    }

    public void setListOfCourses(Collection<Course> listOfCourses) {
        this.listOfCourses = listOfCourses;
    }
    
    @Override
    public String toString() {
        return "Lecturer ID : "+ getId() +
        "\nFirst Name : " + getFirstName() +
        "\nLast Name : " + getLastName() +
        "\nAge : " + getAge() +
        "\nDate Of Birth : " + getDateOfBirth() +
        "\nNIC : " + getNicNo() +
        "\nSpeciality : " + getSpecialities();
    }
}
