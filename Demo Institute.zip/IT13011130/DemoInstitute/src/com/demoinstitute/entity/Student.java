/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

/**
 *
 * @author Research
 */
@Entity(name="STUDENT_TAB")
public class Student extends Person implements Serializable {
    @Column(name = "STUDENT_ID")
    private String registrationId;

    @ManyToMany(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
    @JoinTable(name = "STUDENT_ENROLED_COURSES_TAB",
            joinColumns = {@JoinColumn(name = "STUDENT_ID")}, 
            inverseJoinColumns = {@JoinColumn(name = "COURSE_ID")})
    private Collection<Course> listOfCourses;
    
    public String getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(String registrationId) {
        this.registrationId = registrationId;
    }

    public Collection<Course> getListOfCourses() {
        return listOfCourses;
    }

    public void setListOfCourses(Collection<Course> listOfCourses) {
        this.listOfCourses = listOfCourses;
    }
    
    @Override
    public String toString() {
        String enrolledCoursesData = "";
        if (getListOfCourses() != null && !getListOfCourses().isEmpty()) {
            for (Course course : getListOfCourses()) {
                enrolledCoursesData += "{\n"+course.toString()+ "}\n";
            }
        }
        
        return "Student ID : " + getId() +
        "\nFirst Name : " + getFirstName() +
        "\nLast Name : " + getLastName() +
        "\nAge : " + getAge() +
        "\nDate Of Birth : " + getDateOfBirth() +
        "\nNIC : " + getNicNo() +  
        "\nRegistration ID : " + getRegistrationId() +
        "\nEnrolled Courses : \n{\n" + enrolledCoursesData +    
        "}";
    }
}
