/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

/**
 *
 * @author Research
 */
@Entity(name="COURSE_TAB")
public class Course implements Serializable {
    @Id
    @Column(name="COURSE_ID")
    private String courseId;
    
    @Column(name="COURSE_NAME")
    private String courseName;
    
    @Column(name="COURSE_DURATION")  
    private double courseDuration;
   
    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "listOfCourses")
    private Collection<Student> enrolledStudents;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="LECTURER_ID")
    private  Lecturer conductedLecturer;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public double getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(double courseDuration) {
        this.courseDuration = courseDuration;
    }

    public Lecturer getConductedLecturer() {
        return conductedLecturer;
    }

    public void setConductedLecturer(Lecturer conductedLecturer) {
        this.conductedLecturer = conductedLecturer;
    }

    public Collection<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public void setEnrolledStudents(Collection<Student> enrolledStudents) {
        this.enrolledStudents = enrolledStudents;
    }
    
    @Override
    public String toString() {
        String lecturerData = "";
        if (getConductedLecturer() != null) {
            lecturerData = getConductedLecturer().toString();
        }
        
        return "Course ID : " + getCourseId() +
        "\nCourse Name : " + getCourseName() +
        "\nDuration : " + String.valueOf(getCourseDuration()) +
        "\nLecturer : \n{\n" + lecturerData +    
        "\n}\n";
    } 
}
