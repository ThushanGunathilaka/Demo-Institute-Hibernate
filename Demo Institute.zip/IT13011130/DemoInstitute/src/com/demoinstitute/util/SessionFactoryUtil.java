/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demoinstitute.util;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.derby.impl.tools.sysinfo.Main;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.SessionFactory;

/**
 * Hibernate Utility class with a convenient method to get Session Factory
 * object.
 *
 * @author Research
 */
public class SessionFactoryUtil {
    private static final SessionFactory sessionFactory;

    static {
        Logger logger = Logger.getLogger(Main.class.getName());
        try {
            // Create the SessionFactory (hibernate.cfg.xml)
            sessionFactory = new AnnotationConfiguration().configure("com/demoinstitute/util/hibernate.cfg.xml").buildSessionFactory();
        } catch (Throwable ex) { 
            logger.log(Level.SEVERE, "Initial SessionFactory creation failed.\n{0}", ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    /**
    * Opens a session and will not bind it to a session context
    * @return the session
    */
    public static Session openSession() {
        return sessionFactory.openSession();
    }
    /**
    * Returns a new or current session from the session context.
    * This factory is intended to be used with a hibernate.cfg.xml
    * @return the session
    */
    public static Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }
    /**
    * closes the session factory
    */
    public static void close(){
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
