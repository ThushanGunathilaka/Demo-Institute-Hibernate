Enerprise Application Development
Assignment 2
IT13011130
Gunathilaka D. D. T. M.

Deployement Instructions:
*. Fix Imports
*. Create or Connect to JavaDB Database db/sample (no username, password)
*. Clean and build the project




